function submitHandle(){
    alert('Form Submitted!');
}
function clickHandle(){
    alert('Button Clicked!');
}
function nameChange(){
    var name=document.getElementsByClassName('nameInput')[0].value;
    document.getElementById("name-display1").innerHTML=<p>${name}</p>;
    document.getElementById("name-display2").innerHTML=<p>${name}</p>;
}