const express=require('express');
const bodyparser=require('body-parser');
const mongoose= require('mongoose');
const app=express();
app.use(bodyparser.json());
app.use(bodyparser.urlencoded({extended:true}));
app.use(express.static('public'));

const mongoURL="mongodb+srv://uma_aurora:umauniverse@cluster0.ji5bqww.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";
mongoose.connect(mongoURL)
.then(()=>{ 
    console.log("Connected to the database");
}).catch((err)=>{ 
    console.error("Failed to connect with the database");
})
app.post('/server-post',(req,res)=>{
    var data=req.body;
    console.log(data);
    res.send(data);
});
app.get('/server-get',(req,res)=>{
    var data=req.query;
    console.log(data);
    res.send(data);
});
app.listen(4400,()=>{console.log("Running on port 4400")});